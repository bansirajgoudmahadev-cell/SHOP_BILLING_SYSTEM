# API Reference

## `src.models`
- `PaymentStatus`: string enum: `PAID`, `PENDING`, `PARTIAL`.
- `Item(name, category, quantity, unit_price)`: immutable line item. `line_total` returns quantity × unit price rounded to 2 decimals; `to_dict()` serializes it.
- `Bill(bill_id, customer_name, phone, items, discount_percent, tax_percent, payment_status, created_at)`: immutable invoice. Properties expose `subtotal`, `discount_amount`, `taxable_amount`, `tax_amount`, and `total`. `to_dict()` and `from_dict()` serialize/restore the record.

## `src.validators`
- `ValidationError`: domain validation exception.
- `required_text(value, field, max_length=80)`: strips and checks non-empty bounded text/control characters.
- `validate_item(item)`: checks name/category, quantity 1–10,000 and unit price 0–10,000,000.
- `validate_bill(bill)`: checks bill ID regex, customer, phone format, non-empty items, item validity, discount/tax 0–100 and enum status.
- `prompt_value(prompt, parser, validator=None)`: loops after parse/validation errors; exits cleanly on EOF/interrupt.
- `parse_int(raw)` / `parse_float(raw)`: strict conversion; float parser rejects non-finite values.

## `src.storage.Storage`
- `Storage(data_dir="data")`: initializes data paths, SQLite tables/indexes and performs self-healing load.
- `load_bills() -> list[Bill]`: reads JSON; on malformed schema/JSON archives it to a timestamped `.bak`, initializes an empty register and syncs CSV/SQLite.
- `save_bills(bills)`: atomically replaces JSON and CSV and refreshes SQLite under thread/process locks.
- `audit(action, detail="")`: appends a timestamped audit record.
- `query_index(keyword="", category="", status="")`: searches the SQLite mirror and returns `Bill` objects.

## `src.business_logic.BillingService`
- `all_bills()`: returns persisted bills.
- `create_bill(customer_name, phone, items, discount_percent=0, tax_percent=0, payment_status=PAID)`: validates, calculates and saves a bill; returns it.
- `search(keyword="", category="", status="")`: delegates to indexed search.
- `summary()`: returns bill count, gross sales, average bill, discount total, paid value, unpaid count, overall status and top categories.
- `threshold_warnings()`: flags unpaid/partial bills, discounts ≥50% and bills ≥100,000.

## `src.importer.CSVImporter`
- `import_file(path) -> tuple[int, list[str]]`: validates required headers and each row independently. Returns successful row count and row-numbered error strings; rejected rows are audit logged.

## `src.exporters.ReportExporter`
- `export_markdown(path)`: writes executive summary and bill table.
- `export_csv(path)`: writes standardized bill summary CSV.
- `export_audit(path)`: copies the audit log to the requested destination.

## Interfaces
- `src.ui.run_cli(service)`: ANSI terminal menu and paginated fixed-width tables.
- `main.main()`: CLI entry point.
- `app_streamlit.py`: native Streamlit UI using the same `Storage`, `BillingService`, importer and exporter APIs.

## Persistence schema
Canonical JSON is a list of serialized `Bill` records. CSV stores one bill per row and serializes line items in `items_json`. SQLite table `bills` mirrors the JSON payload and indexes customer, category, payment status and creation date.
