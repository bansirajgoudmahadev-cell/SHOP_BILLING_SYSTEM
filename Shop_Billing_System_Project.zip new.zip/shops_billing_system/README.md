# Shop Billing System

A modular Python 3.10+ shop billing application built from the supplied CampusSolve Project #81 brief. It provides an ANSI menu-driven terminal interface and a separate native Streamlit interface backed by the same `src/` package.

## Features
- Itemized bills, subtotal, percentage discount, tax, grand total and payment status.
- Defensive validation, keyword/category search, paginated terminal tables and summary metrics.
- JSON and CSV persistence, indexed SQLite mirror, atomic replacement and process/thread locking.
- Corrupt JSON recovery to timestamped `.bak`, timestamped audit log, CSV bulk import with row-level errors.
- Markdown, CSV and audit-log exports; threshold warnings; 40 realistic seed bills.
- `unittest` coverage and GitHub Actions CI.

## Requirements
- Python 3.10 or newer.
- Terminal CLI: Python standard library only.
- Web UI: install Streamlit (`python -m pip install streamlit`). The backend remains standard-library-only. No raw HTML or CSS is used in the application code.

## Run the terminal application
From this directory:

```bash
python main.py
```

Choose **Seed/reset demo data** from the menu if you want to reload the supplied 40-record dataset. Data files are created under `data/`.

## Run the Streamlit interface
```bash
python -m pip install streamlit
streamlit run app_streamlit.py
```
The web UI uses native Streamlit widgets and `.streamlit/config.toml`; it imports the same services from `src/` as the CLI.

## Run tests
```bash
python -m unittest discover -s tests -v
```

## CSV import format
Required headers: `bill_id, customer_name, phone, category, items_json, discount_percent, tax_percent, payment_status, created_at`.
`items_json` is a JSON array, e.g. `[{"name":"Notebook","category":"Stationery","quantity":2,"unit_price":45.0}]`.
Rows are validated independently. Invalid rows are skipped and written to the audit log.

## Data and recovery
- `data/bills.json`: canonical structured bill register.
- `data/bills.csv`: portable flat bill register (items stored as JSON in one cell).
- `data/bills.sqlite3`: indexed query mirror, rebuilt/upserted on writes.
- `data/audit_log.txt`: append-only timestamped action log.
- A malformed JSON register is moved to `bills_corrupt_YYYYMMDD_HHMMSS_microseconds.bak`; a clean register is initialized automatically.

## Design note
The supplied brief's required scope is itemized billing, validation, local JSON/CSV persistence, search, executive summaries, bulk CSV import, exports, threshold warnings and readable paginated terminal output. The requested engineering additions (locking, atomic writes, SQLite index, tests and CI) are implemented as robustness enhancements. Pandas, NumPy and Matplotlib are mentioned as optional suggestions in the brief; this project intentionally does not require them.
