"""Launch the standard-library terminal application."""
from src.storage import Storage
from src.business_logic import BillingService
from src.ui import run_cli

def main() -> None:
    storage=Storage(); service=BillingService(storage)
    storage.audit("APPLICATION_START", "Terminal interface launched")
    run_cli(service)
    storage.audit("APPLICATION_STOP", "Terminal interface closed")
if __name__ == "__main__": main()
