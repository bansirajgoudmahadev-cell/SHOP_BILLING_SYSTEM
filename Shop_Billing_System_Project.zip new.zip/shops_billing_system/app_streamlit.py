"""Native Streamlit GUI; shares the exact src backend with the CLI."""
from __future__ import annotations
import streamlit as st
from src.storage import Storage
from src.business_logic import BillingService
from src.models import Item, PaymentStatus
from src.validators import validate_bill, ValidationError
from src.exporters import ReportExporter
from src.importer import CSVImporter

st.set_page_config(page_title="Shop Billing System", page_icon="🧾", layout="wide")
st.title("🧾 Shop Billing System")
st.caption("Itemized billing • Local persistence • Search • Executive reports")
service=BillingService(Storage()); exporter=ReportExporter(service)
menu=st.sidebar.radio("Navigation",["Dashboard","Create Bill","Bill Register","Import CSV","Export Reports","Threshold Warnings"])
if menu=="Dashboard":
    s=service.summary(); cols=st.columns(4)
    for col,label,key in zip(cols,["Bills","Gross sales","Average bill","Discounts"],["bill_count","gross_sales","average_bill","discount_total"]): col.metric(label, f"{s[key]:,.2f}" if key!="bill_count" else s[key])
    st.subheader("Payment overview"); st.write({"Paid value":s["paid_value"],"Unpaid bills":s["unpaid_bill_count"],"Status":s["status"]})
    st.subheader("Top categories"); st.dataframe([{"Category":k,"Units sold":v} for k,v in s["top_categories"]],use_container_width=True)
elif menu=="Create Bill":
    st.subheader("Create itemized bill")
    with st.form("new_bill"):
        customer=st.text_input("Customer name"); phone=st.text_input("Phone (optional)")
        lines=st.number_input("Number of item lines",1,20,1)
        items=[]
        for i in range(int(lines)):
            st.markdown(f"**Item {i+1}**"); c1,c2,c3,c4=st.columns(4)
            name=c1.text_input("Item name",key=f"name{i}"); category=c2.text_input("Category",key=f"cat{i}")
            qty=c3.number_input("Quantity",1,10000,1,key=f"qty{i}"); price=c4.number_input("Unit price",0.0,10000000.0,0.0,key=f"price{i}")
            items.append(Item(name,category,int(qty),float(price)))
        c1,c2,c3=st.columns(3); discount=c1.number_input("Discount %",0.0,100.0,0.0); tax=c2.number_input("Tax %",0.0,100.0,0.0); status=c3.selectbox("Payment status",[s.value for s in PaymentStatus])
        submitted=st.form_submit_button("Generate bill")
    if submitted:
        try:
            bill=service.create_bill(customer,phone,items,discount,tax,PaymentStatus(status))
            st.success(f"Bill {bill.bill_id} saved. Grand total: ₹{bill.total:,.2f}")
            st.table([{"Item":i.name,"Category":i.category,"Qty":i.quantity,"Unit price":i.unit_price,"Line total":i.line_total} for i in bill.items])
            st.write({"Subtotal":bill.subtotal,"Discount":bill.discount_amount,"Tax":bill.tax_amount,"Grand total":bill.total})
        except (ValidationError,ValueError) as exc: st.error(str(exc))
elif menu=="Bill Register":
    c1,c2,c3=st.columns(3); keyword=c1.text_input("Search bill/customer"); category=c2.text_input("Category"); status=c3.selectbox("Payment status",["ALL"]+[s.value for s in PaymentStatus])
    bills=service.search(keyword,category,"" if status=="ALL" else status)
    st.write(f"{len(bills)} bill(s) found")
    st.dataframe([{"Bill ID":b.bill_id,"Customer":b.customer_name,"Items":len(b.items),"Subtotal":b.subtotal,"Discount":b.discount_amount,"Tax":b.tax_amount,"Total":b.total,"Status":b.payment_status.value,"Created":b.created_at} for b in bills],use_container_width=True)
    if bills:
        selected=st.selectbox("View bill details",[b.bill_id for b in bills]); bill=next(b for b in bills if b.bill_id==selected)
        st.subheader(f"Bill {bill.bill_id} — {bill.customer_name}"); st.dataframe([i.to_dict()|{"line_total":i.line_total} for i in bill.items],use_container_width=True)
elif menu=="Import CSV":
    st.write("Upload CSV with the documented required headers and `items_json` array.")
    uploaded=st.file_uploader("Choose CSV",type=["csv"])
    if uploaded and st.button("Import rows"):
        import tempfile, pathlib
        with tempfile.NamedTemporaryFile(suffix=".csv",delete=False) as tmp: tmp.write(uploaded.getvalue()); path=tmp.name
        try:
            count,errors=CSVImporter(service).import_file(path); st.success(f"Imported {count} row(s); rejected {len(errors)}.")
            if errors: st.error("\n".join(errors))
        finally: pathlib.Path(path).unlink(missing_ok=True)
elif menu=="Export Reports":
    st.write("Generate Markdown, CSV and audit-log reports.")
    if st.button("Generate reports"):
        from pathlib import Path
        Path("reports").mkdir(exist_ok=True); exporter.export_markdown("reports/summary.md"); exporter.export_csv("reports/bills_report.csv"); exporter.export_audit("reports/audit_log.txt"); st.success("Saved reports/summary.md, bills_report.csv and audit_log.txt")
    for name,path,mime in [("Markdown summary","reports/summary.md","text/markdown"),("CSV report","reports/bills_report.csv","text/csv"),("Audit log","reports/audit_log.txt","text/plain")]:
        p=__import__('pathlib').Path(path)
        if p.exists(): st.download_button(f"Download {name}",p.read_bytes(),file_name=p.name,mime=mime)
elif menu=="Threshold Warnings":
    warnings=service.threshold_warnings()
    if warnings:
        for warning in warnings: st.warning(warning)
    else: st.success("No threshold warnings.")
