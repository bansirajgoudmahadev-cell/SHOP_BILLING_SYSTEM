"""ANSI terminal interface with fixed-width paginated tables."""
from __future__ import annotations
from src.business_logic import BillingService
from src.models import Item, PaymentStatus
from src.validators import prompt_value, parse_int, parse_float, required_text, ValidationError
from src.importer import CSVImporter
from src.exporters import ReportExporter
from pathlib import Path

C = "\033[96m"; G = "\033[92m"; Y = "\033[93m"; R = "\033[91m"; B = "\033[1m"; X = "\033[0m"
def header() -> None:
    print(f"\n{C}{B}{'='*68}\n                 SHOP BILLING SYSTEM\n{'='*68}{X}")
def paginated_table(rows: list[list[str]], headers: list[str], page_size: int = 8) -> None:
    if not rows: print("No records found."); return
    widths = [min(22, max(len(h), *(len(str(r[i])) for r in rows))) for i,h in enumerate(headers)]
    def line() -> str: return "+" + "+".join("-"*(w+2) for w in widths) + "+"
    for start in range(0, len(rows), page_size):
        print(line()); print("|"+"|".join(f" {headers[i][:widths[i]]:<{widths[i]}} " for i in range(len(headers)))+"|"); print(line())
        for row in rows[start:start+page_size]: print("|"+"|".join(f" {str(row[i])[:widths[i]]:<{widths[i]}} " for i in range(len(headers)))+"|")
        print(line())
        if start + page_size < len(rows):
            try: input(f"{Y}Page {start//page_size+1}; press Enter for next page...{X}")
            except (EOFError, KeyboardInterrupt): return

def run_cli(service: BillingService) -> None:
    exporter=ReportExporter(service); importer=CSVImporter(service)
    while True:
        header(); print(" 1. Create itemized bill\n 2. View all bills\n 3. Search / filter bills\n 4. Executive summary\n 5. Import CSV dataset\n 6. Export reports\n 7. Threshold warnings\n 8. Seed / reset demo data\n 0. Exit")
        choice=input("\nSelect option: ").strip()
        try:
            if choice=="1":
                customer=prompt_value("Customer name: ",str,lambda v:required_text(v,"Customer name"))
                phone=input("Phone (optional): ").strip(); items=[]
                count=prompt_value("Number of item lines (1-20): ",parse_int,lambda v: v if 1<=v<=20 else (_ for _ in ()).throw(ValueError("choose 1-20")))
                for n in range(count):
                    print(f"Item {n+1}"); name=prompt_value(" Name: ",str,lambda v:required_text(v,"Item name",60)); category=prompt_value(" Category: ",str,lambda v:required_text(v,"Category",40))
                    qty=prompt_value(" Quantity: ",parse_int,lambda v:v if 1<=v<=10000 else (_ for _ in ()).throw(ValueError("quantity 1-10000")))
                    price=prompt_value(" Unit price: ",parse_float,lambda v:v if 0<=v<=10_000_000 else (_ for _ in ()).throw(ValueError("price 0-10000000")))
                    items.append(Item(name,category,qty,price))
                discount=prompt_value("Discount % (0-100): ",parse_float,lambda v:v if 0<=v<=100 else (_ for _ in ()).throw(ValueError("0-100")))
                tax=prompt_value("Tax % (0-100): ",parse_float,lambda v:v if 0<=v<=100 else (_ for _ in ()).throw(ValueError("0-100")))
                status=PaymentStatus(prompt_value("Payment status PAID/PENDING/PARTIAL: ",str,lambda v:v.upper() if v.upper() in PaymentStatus._value2member_map_ else (_ for _ in ()).throw(ValueError("choose PAID, PENDING or PARTIAL"))))
                bill=service.create_bill(customer,phone,items,discount,tax,status)
                print(f"{G}Bill {bill.bill_id} created. Subtotal={bill.subtotal:.2f}, discount={bill.discount_amount:.2f}, tax={bill.tax_amount:.2f}, TOTAL={bill.total:.2f}{X}")
            elif choice=="2": show_bills(service.all_bills())
            elif choice=="3":
                keyword=input("Keyword (bill/customer, optional): ").strip(); category=input("Category (optional): ").strip(); status=input("Status PAID/PENDING/PARTIAL (optional): ").strip().upper()
                if status and status not in PaymentStatus._value2member_map_: print(f"{R}Invalid status filter.{X}")
                else: show_bills(service.search(keyword,category,status))
            elif choice=="4":
                s=service.summary(); print(f"\n{B}EXECUTIVE SUMMARY{X}")
                for key,value in s.items(): print(f"{key.replace('_',' ').title():24}: {value}")
            elif choice=="5":
                path=input("CSV file path: ").strip(); imported,errors=importer.import_file(path); print(f"Imported: {imported}; rejected: {len(errors)}")
                for error in errors: print(f"{R}{error}{X}")
            elif choice=="6":
                Path("reports").mkdir(exist_ok=True); exporter.export_markdown("reports/summary.md"); exporter.export_csv("reports/bills_report.csv"); exporter.export_audit("reports/audit_log.txt"); print(f"{G}Reports saved in reports/{X}")
            elif choice=="7":
                warnings=service.threshold_warnings()
                if warnings:
                    for warning in warnings: print(f"{Y}WARNING: {warning}{X}")
                else: print(f"{G}No threshold warnings.{X}")
            elif choice=="8":
                confirm=input("Replace current data with 40 demo records? type YES: ").strip()
                if confirm=="YES":
                    from seed_data import load_seed
                    bills=load_seed(); service.storage.save_bills(bills); service.storage.audit("SEED_RESET",f"Loaded {len(bills)} demo bills"); print("Demo data loaded.")
            elif choice=="0": print("Goodbye."); break
            else: print(f"{R}Choose a listed menu number.{X}")
        except (ValueError, OSError) as exc: print(f"{R}Operation failed safely: {exc}{X}")
        input("\nPress Enter to return to menu...")

def show_bills(bills) -> None:
    rows=[[b.bill_id,b.customer_name,str(len(b.items)),f"{b.total:.2f}",b.payment_status.value,b.created_at[:10]] for b in bills]
    paginated_table(rows,["Bill ID","Customer","Lines","Total","Status","Date"])
