"""Domain models for Shop Billing System."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any

class PaymentStatus(str, Enum):
    PAID = "PAID"
    PENDING = "PENDING"
    PARTIAL = "PARTIAL"

@dataclass(frozen=True)
class Item:
    name: str
    category: str
    quantity: int
    unit_price: float

    @property
    def line_total(self) -> float:
        return round(self.quantity * self.unit_price, 2)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass(frozen=True)
class Bill:
    bill_id: str
    customer_name: str
    phone: str
    items: list[Item]
    discount_percent: float = 0.0
    tax_percent: float = 0.0
    payment_status: PaymentStatus = PaymentStatus.PAID
    created_at: str = ""

    @property
    def subtotal(self) -> float:
        return round(sum(item.line_total for item in self.items), 2)

    @property
    def discount_amount(self) -> float:
        return round(self.subtotal * self.discount_percent / 100, 2)

    @property
    def taxable_amount(self) -> float:
        return round(self.subtotal - self.discount_amount, 2)

    @property
    def tax_amount(self) -> float:
        return round(self.taxable_amount * self.tax_percent / 100, 2)

    @property
    def total(self) -> float:
        return round(self.taxable_amount + self.tax_amount, 2)

    def to_dict(self) -> dict[str, Any]:
        return {
            "bill_id": self.bill_id, "customer_name": self.customer_name,
            "phone": self.phone, "items": [item.to_dict() for item in self.items],
            "discount_percent": self.discount_percent, "tax_percent": self.tax_percent,
            "payment_status": self.payment_status.value, "created_at": self.created_at,
            "subtotal": self.subtotal, "discount_amount": self.discount_amount,
            "tax_amount": self.tax_amount, "total": self.total,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Bill":
        items = [Item(str(i["name"]), str(i["category"]), int(i["quantity"]), float(i["unit_price"])) for i in data["items"]]
        return cls(str(data["bill_id"]), str(data["customer_name"]), str(data.get("phone", "")),
                   items, float(data.get("discount_percent", 0)), float(data.get("tax_percent", 0)),
                   PaymentStatus(str(data.get("payment_status", "PAID")).upper()),
                   str(data.get("created_at", "")))
