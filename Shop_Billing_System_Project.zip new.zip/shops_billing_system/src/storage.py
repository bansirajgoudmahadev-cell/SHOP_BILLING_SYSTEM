"""Thread/process-safe JSON, CSV and indexed SQLite persistence."""
from __future__ import annotations
import csv, json, os, sqlite3, tempfile, threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator, Any
from src.models import Bill

try:
    import fcntl  # POSIX
except ImportError:  # pragma: no cover - Windows
    fcntl = None  # type: ignore[assignment]
try:
    import msvcrt  # Windows
except ImportError:  # pragma: no cover - POSIX
    msvcrt = None  # type: ignore[assignment]

CSV_FIELDS = ["bill_id", "customer_name", "phone", "category", "items_json", "discount_percent", "tax_percent", "payment_status", "created_at", "subtotal", "discount_amount", "tax_amount", "total"]

class Storage:
    """Owns durable files and the SQLite read/query mirror."""
    def __init__(self, data_dir: str | Path = "data") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "bills.json"
        self.csv_path = self.data_dir / "bills.csv"
        self.db_path = self.data_dir / "bills.sqlite3"
        self.lock_path = self.data_dir / ".storage.lock"
        self.audit_path = self.data_dir / "audit_log.txt"
        self._thread_lock = threading.RLock()
        self._initialize_db()
        self.load_bills()

    @contextmanager
    def locked(self) -> Iterator[None]:
        with self._thread_lock:
            with open(self.lock_path, "a+b") as handle:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                elif msvcrt is not None:
                    handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                try:
                    yield
                finally:
                    if fcntl is not None:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                    elif msvcrt is not None:
                        handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)

    def audit(self, action: str, detail: str = "") -> None:
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        with self.locked():
            with open(self.audit_path, "a", encoding="utf-8") as handle:
                handle.write(f"{stamp} | {action} | {detail.replace(chr(10), ' ')}\n")

    def _atomic_write(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content); handle.flush(); os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name): os.unlink(temp_name)

    def _initialize_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS bills (bill_id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, phone TEXT, category TEXT, payment_status TEXT, created_at TEXT, total REAL NOT NULL, payload TEXT NOT NULL)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bills_customer ON bills(customer_name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bills_category ON bills(category)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(payment_status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bills_created ON bills(created_at)")

    def load_bills(self) -> list[Bill]:
        with self.locked():
            if not self.json_path.exists():
                self._atomic_write(self.json_path, "[]\n")
            try:
                raw = json.loads(self.json_path.read_text(encoding="utf-8"))
                if not isinstance(raw, list): raise json.JSONDecodeError("Expected a list", str(self.json_path), 0)
                bills = [Bill.from_dict(row) for row in raw]
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                backup = self.data_dir / f"bills_corrupt_{stamp}.bak"
                os.replace(self.json_path, backup)
                self._atomic_write(self.json_path, "[]\n")
                self._append_audit_unlocked("CORRUPTION_RECOVERY", f"{backup.name}: {exc}")
                bills = []
            self._sync_csv_unlocked(bills)
            self._sync_db_unlocked(bills)
            return bills

    def save_bills(self, bills: list[Bill]) -> None:
        with self.locked():
            payload = json.dumps([b.to_dict() for b in bills], indent=2, ensure_ascii=False) + "\n"
            self._atomic_write(self.json_path, payload)
            self._sync_csv_unlocked(bills)
            self._sync_db_unlocked(bills)

    def _sync_csv_unlocked(self, bills: list[Bill]) -> None:
        import io
        output = io.StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=CSV_FIELDS); writer.writeheader()
        for bill in bills:
            data = bill.to_dict()
            cats = ", ".join(sorted({i.category for i in bill.items}))
            writer.writerow({"bill_id": bill.bill_id, "customer_name": bill.customer_name, "phone": bill.phone,
                "category": cats, "items_json": json.dumps([i.to_dict() for i in bill.items]),
                "discount_percent": bill.discount_percent, "tax_percent": bill.tax_percent,
                "payment_status": bill.payment_status.value, "created_at": bill.created_at,
                "subtotal": bill.subtotal, "discount_amount": bill.discount_amount,
                "tax_amount": bill.tax_amount, "total": bill.total})
        self._atomic_write(self.csv_path, output.getvalue())

    def _sync_db_unlocked(self, bills: list[Bill]) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM bills")
            for bill in bills:
                category = ", ".join(sorted({i.category for i in bill.items}))
                conn.execute("INSERT INTO bills VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (bill.bill_id, bill.customer_name, bill.phone, category, bill.payment_status.value,
                     bill.created_at, bill.total, json.dumps(bill.to_dict())))

    def _append_audit_unlocked(self, action: str, detail: str) -> None:
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        with open(self.audit_path, "a", encoding="utf-8") as handle: handle.write(f"{stamp} | {action} | {detail}\n")

    def query_index(self, keyword: str = "", category: str = "", status: str = "") -> list[Bill]:
        sql = "SELECT payload FROM bills WHERE 1=1"; params: list[Any] = []
        if keyword:
            sql += " AND (customer_name LIKE ? OR bill_id LIKE ?)"; params.extend([f"%{keyword}%", f"%{keyword}%"])
        if category:
            sql += " AND category LIKE ?"; params.append(f"%{category}%")
        if status:
            sql += " AND payment_status = ?"; params.append(status.upper())
        sql += " ORDER BY created_at DESC"
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(sql, params).fetchall()
        return [Bill.from_dict(json.loads(row[0])) for row in rows]
