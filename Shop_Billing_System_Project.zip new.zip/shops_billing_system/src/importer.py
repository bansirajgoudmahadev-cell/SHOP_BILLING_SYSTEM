"""Row-tolerant CSV importer."""
from __future__ import annotations
import csv, json
from pathlib import Path
from src.models import Bill
from src.validators import validate_bill
from src.business_logic import BillingService

class CSVImporter:
    REQUIRED = {"bill_id", "customer_name", "items_json", "discount_percent", "tax_percent", "payment_status"}
    def __init__(self, service: BillingService) -> None: self.service = service

    def import_file(self, path: str | Path) -> tuple[int, list[str]]:
        errors: list[str] = []; imported: list[Bill] = []; seen = {b.bill_id for b in self.service.all_bills()}
        with open(path, newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = self.REQUIRED - set(reader.fieldnames or [])
            if missing: return 0, [f"Missing required columns: {', '.join(sorted(missing))}"]
            for line_no, row in enumerate(reader, start=2):
                try:
                    items_data = json.loads(row["items_json"])
                    from src.models import Item, PaymentStatus
                    bill = Bill(row["bill_id"].strip(), row["customer_name"].strip(), row.get("phone", "").strip(),
                        [Item(str(i["name"]), str(i["category"]), int(i["quantity"]), float(i["unit_price"])) for i in items_data],
                        float(row["discount_percent"]), float(row["tax_percent"]), PaymentStatus(row["payment_status"].strip().upper()),
                        row.get("created_at", "").strip())
                    validate_bill(bill)
                    if bill.bill_id in seen: raise ValueError("duplicate bill_id")
                    seen.add(bill.bill_id); imported.append(bill)
                except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    message = f"Row {line_no}: {exc}"; errors.append(message); self.service.storage.audit("IMPORT_ROW_ERROR", message)
        if imported:
            self.service.storage.save_bills(self.service.all_bills() + imported)
            self.service.storage.audit("CSV_IMPORT", f"Imported {len(imported)} row(s); rejected {len(errors)}")
        return len(imported), errors
