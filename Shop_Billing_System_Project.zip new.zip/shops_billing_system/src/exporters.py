"""Report exporters using only the Python standard library."""
from __future__ import annotations
from pathlib import Path
from src.business_logic import BillingService

class ReportExporter:
    def __init__(self, service: BillingService) -> None: self.service = service
    def export_markdown(self, path: str | Path) -> Path:
        bills = self.service.all_bills(); summary = self.service.summary()
        lines = ["# Shop Billing System Report", "", f"Generated: {__import__('datetime').datetime.now().astimezone().isoformat(timespec='seconds')}", "",
                 "## Executive Summary", "", f"- Bills: {summary['bill_count']}", f"- Gross sales: {summary['gross_sales']:.2f}",
                 f"- Average bill: {summary['average_bill']:.2f}", f"- Discounts: {summary['discount_total']:.2f}",
                 f"- Paid value: {summary['paid_value']:.2f}", f"- Unpaid bills: {summary['unpaid_bill_count']}", "",
                 "## Bill Register", "", "| Bill ID | Customer | Items | Subtotal | Discount | Tax | Total | Status |", "|---|---|---:|---:|---:|---:|---:|---|"]
        for b in bills: lines.append(f"| {b.bill_id} | {b.customer_name} | {len(b.items)} | {b.subtotal:.2f} | {b.discount_amount:.2f} | {b.tax_amount:.2f} | {b.total:.2f} | {b.payment_status.value} |")
        target = Path(path); target.parent.mkdir(parents=True, exist_ok=True); target.write_text("\n".join(lines)+"\n", encoding="utf-8"); return target
    def export_csv(self, path: str | Path) -> Path:
        import csv
        target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["bill_id", "customer_name", "phone", "items_count", "subtotal", "discount_amount", "tax_amount", "total", "payment_status", "created_at"]); writer.writeheader()
            for b in self.service.all_bills(): writer.writerow({"bill_id":b.bill_id,"customer_name":b.customer_name,"phone":b.phone,"items_count":len(b.items),"subtotal":b.subtotal,"discount_amount":b.discount_amount,"tax_amount":b.tax_amount,"total":b.total,"payment_status":b.payment_status.value,"created_at":b.created_at})
        return target
    def export_audit(self, path: str | Path) -> Path:
        target=Path(path); target.parent.mkdir(parents=True,exist_ok=True)
        source=self.service.storage.audit_path
        target.write_text(source.read_text(encoding="utf-8") if source.exists() else "",encoding="utf-8"); return target
