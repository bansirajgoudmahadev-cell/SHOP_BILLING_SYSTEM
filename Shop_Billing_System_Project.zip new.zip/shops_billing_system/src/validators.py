"""Centralized, defensive domain and terminal-input validation."""
from __future__ import annotations
import re
from typing import Callable, TypeVar
from src.models import Bill, Item, PaymentStatus

T = TypeVar("T")
BILL_ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,24}$")
PHONE_RE = re.compile(r"^[0-9+ -]{7,16}$")

class ValidationError(ValueError):
    """Raised when user-supplied data violates the domain schema."""

def required_text(value: str, field: str, max_length: int = 80) -> str:
    clean = str(value).strip()
    if not clean or len(clean) > max_length:
        raise ValidationError(f"{field} must contain 1-{max_length} characters.")
    if any(ord(ch) < 32 for ch in clean):
        raise ValidationError(f"{field} contains unsupported control characters.")
    return clean

def validate_item(item: Item) -> Item:
    required_text(item.name, "Item name", 60)
    required_text(item.category, "Category", 40)
    if not 1 <= item.quantity <= 10000:
        raise ValidationError("Quantity must be between 1 and 10000.")
    if not 0 <= item.unit_price <= 10_000_000:
        raise ValidationError("Unit price must be between 0 and 10000000.")
    return item

def validate_bill(bill: Bill) -> Bill:
    if not BILL_ID_RE.fullmatch(bill.bill_id):
        raise ValidationError("Bill ID must be 2-24 letters, numbers, '_' or '-'.")
    required_text(bill.customer_name, "Customer name", 80)
    if bill.phone and not PHONE_RE.fullmatch(bill.phone):
        raise ValidationError("Phone must be 7-16 digits or common phone separators.")
    if not bill.items:
        raise ValidationError("A bill must contain at least one item.")
    for item in bill.items:
        validate_item(item)
    if not 0 <= bill.discount_percent <= 100:
        raise ValidationError("Discount must be between 0 and 100 percent.")
    if not 0 <= bill.tax_percent <= 100:
        raise ValidationError("Tax must be between 0 and 100 percent.")
    if not isinstance(bill.payment_status, PaymentStatus):
        raise ValidationError("Invalid payment status.")
    return bill

def prompt_value(prompt: str, parser: Callable[[str], T], validator: Callable[[T], T] | None = None) -> T:
    """Loop until parsing and optional validation succeed; EOF/interrupt exits cleanly."""
    while True:
        try:
            raw = input(prompt).strip()
            value = parser(raw)
            return validator(value) if validator else value
        except (ValueError, TypeError) as exc:
            print(f"\033[91mInvalid input: {exc}. Try again.\033[0m")
        except (EOFError, KeyboardInterrupt):
            print("\nInput cancelled.")
            raise SystemExit(0)

def parse_int(raw: str) -> int:
    if not raw:
        raise ValueError("value cannot be blank")
    return int(raw)

def parse_float(raw: str) -> float:
    if not raw:
        raise ValueError("value cannot be blank")
    value = float(raw)
    if value != value or value in (float("inf"), float("-inf")):
        raise ValueError("enter a finite number")
    return value
