"""Business operations and summary calculations."""
from __future__ import annotations
from datetime import datetime
from typing import Any
from src.models import Bill, Item, PaymentStatus
from src.storage import Storage
from src.validators import validate_bill, ValidationError

class BillingService:
    def __init__(self, storage: Storage) -> None:
        self.storage = storage

    def all_bills(self) -> list[Bill]: return self.storage.load_bills()

    def create_bill(self, customer_name: str, phone: str, items: list[Item], discount_percent: float = 0,
                    tax_percent: float = 0, payment_status: PaymentStatus = PaymentStatus.PAID) -> Bill:
        existing = self.all_bills()
        bill = Bill(f"B{datetime.now():%y%m%d%H%M%S%f}"[-18:], customer_name, phone, items,
                    discount_percent, tax_percent, payment_status, datetime.now().astimezone().isoformat(timespec="seconds"))
        validate_bill(bill)
        if any(old.bill_id == bill.bill_id for old in existing): raise ValidationError("Duplicate bill ID; retry.")
        self.storage.save_bills(existing + [bill]); self.storage.audit("BILL_CREATED", f"{bill.bill_id} total={bill.total:.2f}")
        return bill

    def search(self, keyword: str = "", category: str = "", status: str = "") -> list[Bill]:
        return self.storage.query_index(keyword, category, status)

    def summary(self) -> dict[str, Any]:
        bills = self.all_bills(); count = len(bills); revenue = round(sum(b.total for b in bills), 2)
        paid = sum(b.total for b in bills if b.payment_status == PaymentStatus.PAID)
        pending = sum(1 for b in bills if b.payment_status != PaymentStatus.PAID)
        discounts = round(sum(b.discount_amount for b in bills), 2)
        return {"bill_count": count, "gross_sales": revenue, "average_bill": round(revenue/count, 2) if count else 0.0,
                "discount_total": discounts, "paid_value": round(paid, 2), "unpaid_bill_count": pending,
                "status": "NO SALES" if not count else ("ATTENTION: unpaid bills" if pending else "ALL CLEAR"),
                "top_categories": self._top_categories(bills)}

    @staticmethod
    def _top_categories(bills: list[Bill]) -> list[tuple[str, int]]:
        counts: dict[str, int] = {}
        for bill in bills:
            for item in bill.items: counts[item.category] = counts.get(item.category, 0) + item.quantity
        return sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))[:5]

    def threshold_warnings(self) -> list[str]:
        warnings: list[str] = []
        for bill in self.all_bills():
            if bill.payment_status != PaymentStatus.PAID: warnings.append(f"{bill.bill_id}: payment status is {bill.payment_status.value}")
            if bill.discount_percent >= 50: warnings.append(f"{bill.bill_id}: unusually high discount ({bill.discount_percent:.1f}%)")
            if bill.total >= 100000: warnings.append(f"{bill.bill_id}: high-value bill ({bill.total:.2f})")
        return warnings
