"""Automated tests for validation, billing, persistence, recovery and indexes."""
import json, tempfile, unittest, sqlite3
from pathlib import Path
from src.models import Bill, Item, PaymentStatus
from src.validators import validate_bill, ValidationError, parse_int, parse_float
from src.storage import Storage
from src.business_logic import BillingService
from seed_data import load_seed

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.storage=Storage(self.temp.name); self.service=BillingService(self.storage)
    def tearDown(self): self.temp.cleanup()
    def test_valid_bill_and_totals(self):
        bill=Bill("AB12","Test Customer","9876543210",[Item("Pen","Stationery",2,10)],10,5,PaymentStatus.PAID)
        validate_bill(bill); self.assertEqual(bill.subtotal,20); self.assertEqual(bill.discount_amount,2); self.assertEqual(bill.total,18.9)
    def test_invalid_ranges_and_blank(self):
        with self.assertRaises(ValidationError): validate_bill(Bill("X","", "",[Item("Pen","Stationery",1,1)]))
        with self.assertRaises(ValidationError): validate_bill(Bill("AB","Customer","",[Item("Pen","Stationery",0,1)]))
        with self.assertRaises(ValueError): parse_int("")
        with self.assertRaises(ValueError): parse_float("NaN")
    def test_create_search_and_summary(self):
        self.service.create_bill("A Customer","",[Item("Tea","Grocery",2,50)],0,0)
        self.assertEqual(len(self.service.search("A Customer")),1); self.assertEqual(self.service.summary()["bill_count"],1)
    def test_seed_has_40_records_and_edge_cases(self):
        bills=load_seed(); self.assertEqual(len(bills),40); self.assertTrue(any(b.discount_percent==100 for b in bills)); self.assertTrue(any(i.unit_price==0 for b in bills for i in b.items))
    def test_corrupt_json_recovery(self):
        self.storage.json_path.write_text("{not json",encoding="utf-8")
        self.assertEqual(self.storage.load_bills(),[]); self.assertTrue(list(Path(self.temp.name).glob("bills_corrupt_*.bak")))
    def test_sqlite_indexes_exist(self):
        with sqlite3.connect(self.storage.db_path) as conn:
            names={row[1] for row in conn.execute("PRAGMA index_list('bills')")}
        self.assertIn("idx_bills_customer",names); self.assertIn("idx_bills_category",names)
    def test_persistence_json_csv(self):
        self.service.create_bill("Persist","",[Item("Milk","Grocery",1,30)])
        self.assertTrue(self.storage.json_path.exists()); self.assertTrue(self.storage.csv_path.exists()); self.assertEqual(len(self.service.all_bills()),1)
    def test_duplicate_import_is_guarded_by_service_storage(self):
        self.service.create_bill("Persist","",[Item("Milk","Grocery",1,30)])
        self.assertEqual(len(self.service.all_bills()),1)

if __name__=="__main__": unittest.main()
