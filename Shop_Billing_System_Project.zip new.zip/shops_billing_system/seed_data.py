"""Deterministic 40-record realistic demo dataset."""
from __future__ import annotations
import json, csv
from pathlib import Path
from datetime import datetime, timedelta
from src.models import Bill, Item, PaymentStatus

NAMES=["Aarav Sharma","Priya Reddy","Rahul Kumar","Sneha Patel","Mohammed Imran","Ananya Rao","Kiran Goud","Divya Nair","Arjun Mehta","Sana Khan"]
PRODUCTS=[("Rice 5kg","Groceries",1,320.0),("Cooking Oil 1L","Groceries",2,145.0),("Notebook","Stationery",4,45.0),("Blue Pen","Stationery",5,10.0),("LED Bulb","Electrical",2,85.0),("Bath Soap","Personal Care",3,38.0),("Tea Powder 250g","Groceries",1,120.0),("Phone Charger","Electronics",1,499.0),("Water Bottle","Household",1,0.0),("Floor Cleaner","Household",2,110.0)]
def load_seed() -> list[Bill]:
    bills=[]; base=datetime.now().astimezone()
    for n in range(40):
        product=PRODUCTS[n%len(PRODUCTS)]; name,cat,qty,price=product
        items=[Item(name,cat,qty+(1 if n%7==0 else 0),price)]
        if n%3==0:
            p=PRODUCTS[(n+3)%len(PRODUCTS)]; items.append(Item(p[0],p[1],p[2],p[3]))
        discount=[0,5,10,15,20,50,100][n%7]; tax=[0,5,12,18][n%4]
        status=[PaymentStatus.PAID,PaymentStatus.PENDING,PaymentStatus.PARTIAL][n%3]
        bills.append(Bill(f"SEED{n+1:04d}",NAMES[n%len(NAMES)],f"98765{n:05d}",items,discount,tax,status,(base-timedelta(days=n)).isoformat(timespec="seconds")))
    return bills

def write_seed(directory: str|Path="data") -> None:
    path=Path(directory); path.mkdir(parents=True,exist_ok=True); bills=load_seed()
    (path/"bills.json").write_text(json.dumps([b.to_dict() for b in bills],indent=2)+"\n",encoding="utf-8")
    fields=["bill_id","customer_name","phone","category","items_json","discount_percent","tax_percent","payment_status","created_at","subtotal","discount_amount","tax_amount","total"]
    with (path/"bills.csv").open("w",newline="",encoding="utf-8") as handle:
        writer=csv.DictWriter(handle,fieldnames=fields); writer.writeheader()
        for b in bills: writer.writerow({"bill_id":b.bill_id,"customer_name":b.customer_name,"phone":b.phone,"category":", ".join(sorted({i.category for i in b.items})),"items_json":json.dumps([i.to_dict() for i in b.items]),"discount_percent":b.discount_percent,"tax_percent":b.tax_percent,"payment_status":b.payment_status.value,"created_at":b.created_at,"subtotal":b.subtotal,"discount_amount":b.discount_amount,"tax_amount":b.tax_amount,"total":b.total})
if __name__=="__main__": write_seed()
